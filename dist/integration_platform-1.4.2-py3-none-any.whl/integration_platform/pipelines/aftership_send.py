
from integration_platform.pipelines.base import Pipeline
from integration_platform.connectors import AfterShip, AcumaticaAPI
from integration_platform.transform.aftership import Transform
from integration_platform.connectors.sql import SQLConnector, AcumaticaDbQueries

class SendToAfterShip(Pipeline):
    '''`SendToAfterShip`(Pipeline)
    ---
    <hr>

    Pipeline to send new tracking data to AfterShip

    # Extraction
     - Three data sources are used in extraction:
        - **slugs_extract**: Pulls Slugs from CentralStore, not being used as of 5/6/26
            - Query: *select * from SlugsAfterShip*
        - **shipment_extract**: Extract Shipments that have tracking data from AcumaticaDb
            - Query: **Aftership_Shipments**
        - **aftership_extract**: Retrieves tracking data from AfterShip via :class:`~connectors.aftership.AfterShip`.:meth:`~connectors.aftership.AfterShip.retrieve_trackings`       

    # Transformation
     - For each row in the response back from Aftership, determine if the **shipment_tags** or **customer** information differs from that of our **shipment_extract** query
     - If a difference is found, the updated data is to be sent back to Aftership
     
    # Load
     - Send any rows having a discrepancy between Acu and Aftership to Aftership for update via :class:`~connectors.aftership.AfterShip`.:meth:`~connectors.aftership.AfterShip.put_data`

    # Results Logging
     - None needed
    '''
    def __init__(self, function: str, env: str='prod'):
        super().__init__(pipeline_name='aftership-send', function=function, env=env)
        self.acudb: SQLConnector[AcumaticaDbQueries] = SQLConnector(
            pipeline=self, database_name='AcudevDb' if env == 'dev' else 'AcumaticaDb'
        )
        self.aftership = AfterShip(self)
        # self.acuapi = AcumaticaAPI(self)
        self.transformer = Transform(self)
        pass



    def extract(self):
        data_extract = {
            'slugs_extract': self.centralstore.query_db('select * from SlugsAfterShip'),
            'log_extract': self.centralstore.query_db('select * from _util.AftershipLog'),
            'shipment_extract': self.acudb.query_to_dataframe(self.acudb.queries.Aftership_Shipments),
            'old_aftership_records': self.centralstore.query_db('select * from acu.AftershipExport')
        }
        return data_extract

    def transform(self, data_extract):
        data_transformed = self.transformer.transform_send(data_extract)
        return data_transformed
    
    def load(self, data_transformed):
        for i, row in enumerate(data_transformed):
            prefix = f'{i+1}/{len(data_transformed)}, {len(data_transformed)} to go: '
            self.logger.info(f'{prefix}Posting data to aftership for {row['OrderNbr']}-{row['ShipmentNbr']}-{row['Tracking']}')
            self.aftership.post_data(self.aftership.tracking_endpoint, row['formatted'])
        data_loaded = data_transformed
        return data_loaded
    
    def log_results(self, data_loaded):
        pass
