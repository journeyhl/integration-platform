
from integration_platform.pipelines import Pipeline
from integration_platform.connectors import AcumaticaAPI
from integration_platform.transform.audit_fulfillment import Transform

class AuditFulfillment(Pipeline):
    def __init__(self, function: str):
        super().__init__('audit-fulfillment', function)
        self.acu_api = AcumaticaAPI(self)
        self.transformer = Transform(self)


    def extract(self):
        data_extract = self.centralstore.query_to_dataframe(self.acudb.queries.AuditFulfillment)
        return data_extract

    def transform(self, data_extract):
        data_transformed = data_extract
        return data_transformed
    
    def load(self, data_transformed):
        data_loaded = data_transformed
        return data_loaded
    
    def log_results(self, data_loaded):
        pass
