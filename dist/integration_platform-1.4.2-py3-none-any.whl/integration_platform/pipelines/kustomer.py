from integration_platform.pipelines import Pipeline
from integration_platform.connectors import AcumaticaAPI, Kustomer
from integration_platform.transform.kustomer import Transform
from integration_platform.load.kustomer import Load
import polars as pl
from typing import Literal
import json

from integration_platform.connectors.sql import SQLConnector, AcumaticaDbQueries
class SendOrderDetailsToKustomer(Pipeline):
    '''`SendOrderDetailsToKustomer`(Pipeline)
    ---
    <hr>

    Gets all recent orders from AcumaticaDb/orders that haven't been sent to Kustomer

    Pulls shipment details & tracking, formats, then sends to Kustomer

    # Extraction
     - Gets all recent orders from AcumaticaDb/orders that haven't been sent to Kustomer

    # Transformation
     - Transforms extracted data into a format needed for Kustomer Webhook

    # Load
     - Send formatted payload to Kustomer Webhook and upsert to **K_OrderIngest** in *AcumaticaDb* every 25 rows

    # Results Logging
     - None needed
    '''    
    def __init__(self, function: str, env: str='prod'):
        super().__init__(pipeline_name='kustomer-orders', function=function, env=env)
        self.acudb: SQLConnector[AcumaticaDbQueries] = SQLConnector(
            pipeline=self, database_name='AcudevDb' if env == 'dev' else 'AcumaticaDb'
        )
        self.transformer = Transform(self)
        self.api = Kustomer(self)
        self.loader = Load(self)


    def extract(self) -> pl.DataFrame:
        data_extract = self.acudb.query_to_dataframe(self.order_query)

        return data_extract

    def transform(self, data_extract):
        data_transformed = self.transformer.transform(data_extract)
        return data_transformed
    
    def load(self, data_transformed):
        data_loaded = self.loader.landing(data_transformed)
        self.logger.info(f'Upserted {len(data_loaded)} total rows')
        return data_transformed
    
    def log_results(self, data_loaded):
        pass


    def _re_init(self, type: Literal['ingest', 'backfill'] = 'ingest'):
        '''`_re_init`(self, type: *str* = 'ingest' | 'backfill')
        ---
        <hr>
        
        Method to re initialize the Kustomer pipeline with the specified configuration ***and then run it***
        
        **If no type value is passed, defaults to *'ingest'***

            
        <hr>
        
        Parameters
        ---
        :param (*str = 'ingest' | 'backfill'*) `type`: Defaults to 'ingest'. Accepted values are 'ingest' or 'backfill'. 
        
            - Depeding on which, the pipeline's self.:attr:`~order_query` value is set to either :attr:`~connectors.sql.AcumaticaDbQueries.Kustomer_OrderIngest` or :attr:`~connectors.sql.AcumaticaDbQueries.Kustomer_OrderIngestBackfill`
        '''
        if type == 'ingest':
            self.order_query = self.acudb.queries.Kustomer_OrderIngest
        elif type == 'backfill':
            self.order_query = self.acudb.queries.Kustomer_OrderIngestBackfill
        self.run()