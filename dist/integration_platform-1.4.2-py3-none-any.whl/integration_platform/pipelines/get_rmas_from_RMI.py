

from integration_platform.pipelines import Pipeline
from integration_platform.connectors import RMIAPI, SQLConnector
from integration_platform.transform.rmi_receipt_pull import Transform


class GetRMAsFromRMI(Pipeline):
    '''`GetRMAsFromRMI`(Pipeline)
    ---
    <hr>

    Hits RMI's *RMAs* endpoint, retrieves all RMAs and upsert to **rmi_RMAs** in db_CentralStore

    # Extraction
     - Extract RMAs data via :class:`~connectors.rmi_api.RMIAPI`.:meth:`~connectors.rmi_api.RMIAPI.target_api`

    # Transformation
     - Transforms extracted data into format needed for upsert to **RMAStatus**

    # Load
     - Upserts data to **RMAStatus** via :meth:`~connectors.sql.SQLConnector.checked_upsert`

    # Results Logging
     - None needed
    '''
    def __init__(self, function: str, rmi_api: RMIAPI | None = None):
        '''`__init__`(self)
        ---
        <hr>
        
        Initializes GetRMAsFromRMI Pipeline 
        
        Sets
        ---
        >>> self.rmi = RMIAPI(self)
        >>> self.transformer = Transform(self)  
        >>> self.payload_template = ["lastModifiedDateFrom", "lastModifiedDateTo"]   
        '''
        super().__init__('rmi-rmas', function)
        self.rmi = RMIAPI(self) if rmi_api == None else rmi_api
        self.transformer = Transform(self)
        self.payload_template = ["lastModifiedDateFrom", "lastModifiedDateTo"]        


    def extract(self):
        data_extract = self.rmi.target_api(endpoint='RMAs', payload=self.payload_template, lookback_window_days=7)
        return data_extract
    
    def transform(self, data_extract):
        data_transformed = self.transformer.transform_status_records(data_extract)
        return data_transformed


    def load(self, data_transformed):
        total = len(data_transformed)
        self.logger.info(f'{total} rows to upsert')
        data_loaded = self.centralstore.checked_upsert_paginated(table_name='rmi_RMAStatus', data=data_transformed, page_size=100)
        bp = 'here'
        return data_transformed

    def log_results(self, data_loaded):
        pass