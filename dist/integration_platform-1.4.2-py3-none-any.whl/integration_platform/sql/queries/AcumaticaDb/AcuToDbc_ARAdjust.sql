/*Pulls Acumatica Accounts Receivable document adjustments
Acumatica definition: 
The fact of application of one accounts receivable document to another, 
which results in an adjustment of the balances of both documents. 
It can be either an application of a payment document to an invoice document 
(such as when a payment closes an invoice), or an application of one payment 
document to another, such as an application of a customer refund to a payment.
*/
select rtrim(b.AcctCD) CustomerID
	 , a.AdjdDocType
	 , jd.Status AdjdType
	 , a.AdjdRefNbr
	 , a.AdjgDocType
	 , jg.Status AdjgType
	 , a.AdjgRefNbr
	 , a.AdjNbr
	 , a.AdjdOrderType
	 , a.AdjdOrderNbr
	 , a.AdjBatchNbr
	 , cast(a.AdjgDocDate as date) AdjgDocDate
	 , cast(a.AdjdDocDate as date) AdjdDocDate
	 , cast(a.CuryAdjgAmt as decimal(18,2)) AdjgAmt
	 , cast(a.CuryAdjgDiscAmt as decimal(18,2)) AdjgDiscAmt
	 , cast(a.CuryAdjgPPDAmt as decimal(18,2)) AdjgPPDAmt
	 , cast(a.CuryAdjgWOAmt as decimal(18,2)) AdjgWOAmt
	 , cast(a.CuryAdjdAmt as decimal(18,2)) AdjdAmt
	 , cast(a.CuryAdjdOrigAmt as decimal(18,2)) AdjdOrigAmt
	 , cast(a.CuryAdjdDiscAmt as decimal(18,2)) AdjdDiscAmt
	 , cast(a.CuryAdjdPPDAmt as decimal(18,2)) AdjdPPDAmt
	 , cast(a.CuryAdjdWOAmt as decimal(18,2)) AdjdWOAmt
	 , cast(a.AdjAmt as decimal(18,2)) AdjAmt
	 , cast(a.AdjDiscAmt as decimal(18,2)) AdjDiscAmt
	 , cast(a.AdjPPDAmt as decimal(18,2)) AdjPPDAmt
	 , cast(a.AdjWOAmt as decimal(18,2)) AdjWOAmt
	 , cast(a.RGOLAmt as decimal(18,2)) RGOLAmt
	 , a.WriteOffReasonCode
	 , a.Released
	 , a.Hold
	 , a.AdjdARAcct
	 , aa.Description AdjdARAcctDescr
	 , a.AdjdARSub
	 , cast(a.StatementDate as date) StatementDate
	 , a.AdjgFinPeriodID
	 , a.AdjdFinPeriodID
	 , a.AdjgTranPeriodID
	 , a.AdjdTranPeriodID
	 , a.Voided
	 , a.VoidAdjNbr
	 , a.PendingPPD
	 , a.AdjdHasPPDTaxes
	 , a.TaxInvoiceNbr
	 , a.IsMigratedRecord
	 , a.IsInitialApplication
	 , a.Recalculatable
	 , a.IsCCPayment
	 , a.PaymentPendingProcessing
	 , a.PaymentReleased
	 , a.IsCCAuthorized
	 , a.IsCCCaptured
	 , a.PaymentCaptureFailed
     , coalesce(replace(uc.Email, '@journeyhl.com', ''), replace(uc.username, 'journeyhl.com\', '')) Created_Username
     , uc.FullName Created_Name
     , a.CreatedByScreenID Created_ScreenID
     , a.CreatedDateTime Created_Datetime
     , coalesce(replace(um.Email, '@journeyhl.com', ''), replace(um.username, 'journeyhl.com\', '')) LastMod_Username
     , um.FullName LastMod_Name
     , a.LastModifiedByScreenID LastMod_ScreenID
     , a.LastModifiedDateTime LastMod_Datetime
	 , a.NoteID
	 , a.InvoiceID NoteID_Invoice
	 , a.PaymentID NoteID_Payment
	 , a.MemoID NoteID_Memo
from ARAdjust a
inner join Users uc on a.CompanyID = uc.CompanyID and a.CreatedByID = uc.PKID
inner join Users um on a.CompanyID = um.CompanyID and a.LastModifiedByID = um.PKID
inner join BAccount b on a.CompanyID = b.CompanyID and a.CustomerID = b.BAccountID
left join JJStatusLookup jd on a.AdjdDocType = jd.CStatus and jd.tbl = 'ARRegister.DocType'
left join JJStatusLookup jg on a.AdjgDocType = jg.CStatus and jg.tbl = 'ARRegister.DocType'
left join Account aa on a.CompanyID = aa.CompanyID and a.AdjdARAcct = aa.AccountID
left join Sub sa on a.CompanyID = sa.CompanyID and a.AdjdARSub = sa.SubID
where a.CompanyID = 2
and dateadd(hour, -4, a.LastModifiedDateTime) >= dateadd(day, -1, getdate())