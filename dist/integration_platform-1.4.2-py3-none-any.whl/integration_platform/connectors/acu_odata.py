import requests
import xmltodict
import logging

class AcuOData:
    def __init__(self, pipeline):
        self.pipeline = pipeline
        self.logger = logging.getLogger(f'{pipeline.pipeline_name}.AcuOData')
        self.session = requests.Session()
        self.session.auth = ('***REMOVED***', '***REMOVED***')
        pass

    def get_data(self, url: str):
        self.response = self.session.get(url).text
        self.response = xmltodict.parse(self.response)['feed']
        test = self.response
        bp = 'here'

  
if __name__ == '__main__':

    odata = AcuOData('pipeline')
    odata.get_data('https://erp.journeyhl.com/ODATA/JHL/JHL RMI Shipment API')
    bp = 'here'
