from integration_platform.config.settings import ACUMATICA_API
from integration_platform.helpers.acu_api_helper import AcumaticaAPIHelper
import requests
import logging
import json
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
import time
class AcumaticaAPI:
    def __init__(self, pipeline, env: str='prod'):
        """`init`(self, pipeline: *Pipeline | str*)
        ---
        <hr>
        
        Initializes AcumaticaAPI connector and Authenticates

        <hr>
        
        Parameters
        ---
        :param (*Pipeline | str*) `pipeline`: Pipeline the connector belongs to
        
        <hr>
        
        Sets
        ---
        >>> self.logger = logging.getLogger(f'{pipeline.pipeline_name}.acu_api')
        >>> self.pipeline = pipeline
        >>> self.version = '22.200.001'
        >>> self.auth_type = 'Cookie'
        >>> self.uri = 'https://erp.journeyhl.com/entity'
        >>> self.endpoint_name = 'pyplatform'
        >>> self.base_uri = f'{self.uri}/{self.endpoint_name}/{self.version}'
        >>> self.username = ACUMATICA_API['username']
        >>> self.password = ACUMATICA_API['password']
        >>> self.company = 'JHL'
        >>> self.data_log = []
        >>> self.session = requests.Session()
        >>> self._auth() #logs into Acumatica API
        
        **self._auth** Authenticates using creds from :data:`~config.settings.ACUMATICA_API`
        """
        self.pipeline = pipeline
        self.env = env
        self.helper = AcumaticaAPIHelper(self)
        if type(pipeline) == str:
            self.logger = logging.getLogger(f'{pipeline}.AcumaticaAPI')
        else:
            self.logger = logging.getLogger(f'{pipeline.pipeline_name}.AcumaticaAPI')
        self.auth_type = 'Cookie'
        uri_env = 'erp' if env == 'prod' else 'acudev'
        '''Acumatica subdomain. If running in dev, use acudev.journeyhl.com instead of erp.journeyhl.com for production'''
        
        uri = f'https://{uri_env}.journeyhl.com/entity'

        self.auth_url = f'https://{uri_env}.journeyhl.com/entity/auth'
        '''Base portion of authentication url. When used, ***'/login'*** or ***'/logout'*** *must* be appended'''

        endpoint_name = 'IntegrationPlatform'
        '''Endpoint name within Acumatica'''
        version = '24.200.001'
        '''Acumatica API version (set in Acumatica - [Web Service Endpoints - IntegrationPlatform](https://erp.journeyhl.com/(W(5))/Main?CompanyID=JHL&ScreenId=SM207060&InterfaceName=IntegrationPlatform&GateVersion=24.200.001)'''

        self.base_uri = f'{uri}/{endpoint_name}/{version}'
        '''Global base_uri to use with all Acumatica API calls. ***/*** must be appended with any endpoint'''

        self.username = ACUMATICA_API['username']
        '''Primary username'''
        self.password = ACUMATICA_API['password']
        '''Primary password'''
        self.username2 = ACUMATICA_API['username2']
        '''Fallback username'''
        self.password2 = ACUMATICA_API['password2']
        '''Fallback password'''
        self.username3 = ACUMATICA_API['username3']
        '''Alternate fallback username'''
        self.password3 = ACUMATICA_API['password3']
        '''Alternate fallback password'''
        self.company = 'JHL'
        self.data_log = []
        self.calls = 0
        self.login_attempts = 0
        self._auth_()
        if env == 'dev':
            self.logger.warning(f'Running in dev environment!!!')




#region SalesOrder
    #region order_create_receipt
    def order_create_receipt(self, order_data: dict):
        '''order_create_receipt`(self, order_data)`
    ---
    <hr>

    Creates Receipt for Open SalesOrder

    For **RC Orders only**

    <hr>

    Parameters
    -------------

    :param (*dict*) `order_data`: Dictionary of Order data. Must contain OrderType, OrderNbr, and AcctCD

    '''
        self.logger.info(f'Creating Receipt for {order_data['OrderNbr']}')
        payload = self.helper.format_order_create_receipt(order=order_data)
        try:
            response = self.session.post(f'{self.base_uri}/SalesOrder/SalesOrderCreateReceipt', json=payload)
            response_str = f'{response.status_code} {response.reason}'
            self.logger.info(response_str)
        except Exception as e:
            bp = 'here'
        self.helper.format_data_log_entry(entity='SalesOrder', key_value=order_data['OrderNbr'], operation=f'POST - Create Receipt', payload=payload, response=response_str, tstamp=datetime.now(ZoneInfo('America/New_York')), options='append')
    #endregion

    #region order_create_shipment
    def order_create_shipment(self, order_data: dict):
        '''`order_create_shipment`(self, order_data: *dict*)
        ---
        <hr>
        
        Creates Shipment for Open SalesOrder
            
        <hr>
        
        Parameters
        ---
        :param (*dict*) `order_data`: Dictionary of Order data. Must contain OrderType, OrderNbr, and AcctCD
        
        <hr>
        
        Returns
        ---
        '''
        self.logger.info(f'Creating Shipment for {order_data['OrderNbr']}')
        payload = self.helper.format_order_create_shipment(order=order_data)
        try:
            response = self.session.post(f'{self.base_uri}/SalesOrder/SalesOrderCreateShipment', json=payload)
            response_str = f'{response.status_code} {response.reason}'
        except Exception as e:
            bp = 'here'
        if response_str and response_str == '202 Accepted':
            self.logger.info(f'{order_data['OrderNbr']}: Shipment created! {response_str}')
        else:
            self.logger.warning(response_str)
        self.helper.format_data_log_entry(entity='SalesOrder', key_value=order_data['OrderNbr'], operation=f'POST - Create Shipment', payload=payload, response=response_str, tstamp=datetime.now(ZoneInfo('America/New_York')), options='append')
    #endregion

    #region sales_order_get_shipment
    def sales_order_get_shipment(self, order_data):
        '''`sales_order_get_shipment`(self, order_data)
    ---
    <hr>
    Returns Shipment details for a given *Sales Order*

    <hr>

    Parameters
    -------------

    :param (*dict*) `order_data`: Dictionary of Order data. Must contain OrderType and OrderNbr

    <hr>

    Returns
    -------------

        __shipment_data__ (dict): Formatted dict of Shipment data for order. If no shipment, Shipment data is None

    '''
        self.logger.info(f'Checking for any shipments on {order_data['OrderNbr']}')
        try:
            response = self.session.get(f'{self.base_uri}/SalesOrder/{order_data['OrderType']}/{order_data['OrderNbr']}?$expand=Shipments')
            order_info = response.json()
        except Exception as e:
            order_info = None
            self.logger.error(f'Error getting {order_data['OrderNbr']}')
        
        if order_info:
            self.logger.info(f'{order_data['OrderNbr']} parsed successfully. Status: {order_info['Status']['value']}, Shipments: {len(order_info['Shipments'])}')
            if len(order_info['Shipments']) > 1:
                shipment = next((shipment for shipment in order_info['Shipments']
                                    if datetime.strptime(shipment['LastModifiedDateTime']['value'][:-6], '%Y-%m-%dT%H:%M:%S.%f') >= datetime.now(ZoneInfo('America/New_York')) - timedelta(minutes=10)
                                    ), None)
            elif len(order_info['Shipments']) != 0:
                shipment = order_info['Shipments'][0]
            else:
                shipment = None
            if shipment:
                shipment_data = {
                    'ShipmentNbr': shipment['ShipmentNbr'].get('value'),
                    'CustomerID': order_info['CustomerID'].get('value'),
                    'Description': order_info['Description'].get('value'),
                    'ExtRefNbr': order_info['ExternalRef'].get('value'),
                    'OrderNbr': order_data['OrderNbr'],
                    'OrderType': order_data['OrderType']
                }
                self.logger.info(f'{shipment['ShipmentNbr'].get('value')} found for {order_data['OrderNbr']}')
                return shipment_data
            else:
                self.logger.warning(f'No Shipment found for {order_data['OrderNbr']}')
                
        shipment_data = {
            'ShipmentNbr': None,
            'CustomerID': None,
            'Description': None,
            'ExtRefNbr': None,
            'OrderNbr': order_data['OrderNbr'],
            'OrderType': order_data['OrderType']
        }
        return shipment_data
    #endregion
    
    
    #region rc_send_to_wh
    def rc_send_to_wh(self, OrderNbr, OrderType, CustomerID):
        ''':class:`~integration_platform.connectors.acu_api.AcumaticaAPI`.:meth:`~integration_platform.connectors.acu_api.AcumaticaAPI.rc_send_to_wh`
        ---
        
        * Marks an *Order*'s **RC Ship to Warehouse** attribute to true. (AttributeRCSHP2WH)

        * API Method: **PUT**
        
        Parameters
        ---
        :param (*str*) `OrderNbr`: OrderNbr of Order to update (AR078365)
        :param (*str*) `OrderType`: OrderType of Order to update (RC)
        :param (*str*) `CustomerID`: CustomerID or AcctCD of Customer on Order (C0090306, C0067451)

        Returns
        ---

            __self.status_description__ (str): Details of interaction with Acumatica API
            __body__ (dict): Dictionary of what was sent to Acumatica API

        '''
        payload = self.helper.format_rc_send_to_wh(order={'OrderNbr': OrderNbr, 'OrderType': OrderType, 'CustomerID': CustomerID})
        
        try:
            response = self.session.put(f'{self.base_uri}/SalesOrder', json=payload)
            self.parse_response(response, {'type': 'Order', 'attribute': 'AttributeRCSHP2WH'})
        except Exception as e:
            try:                    
                self._logout_()
                self._auth_()
                response = self.session.put(f'{self.base_uri}/SalesOrder', json=payload)
                self.parse_response(response, {'type': 'Order', 'attribute': 'AttributeRCSHP2WH'})
            except Exception as e:
                self.status_description = 'FAILURE'
                bp = 'here'
        self.helper.format_data_log_entry(entity='SalesOrder', key_value=OrderNbr, operation='PUT - Mark RC Order as Sent To WH', payload=payload, response=self.status_description, tstamp=datetime.now(ZoneInfo('America/New_York')), options='append')
        return self.status_description, payload
    #endregion
    

    
    #region validate_order_address
    def validate_order_address(self, order_data: dict):        
        ''':class:`~integration_platform.connectors.acu_api.AcumaticaAPI`.:meth:`~integration_platform.connectors.acu_api.AcumaticaAPI.validate_order_address`
        ---
        
        Given a dict containing **OrderType** and **OrderNbr**, attempts to validate a Sales Order's addresses
        
        Parameters
        ---
        :param (*dict*) `order_data`: dict containing **OrderNbr** and **OrderType**
        '''
        payload = self.helper.format_validate_order_address(order=order_data)

        response = self.session.post(f'{self.base_uri}/SalesOrder/ValidateAddresses', json=payload)
        response_str = f'{response.status_code} {response.reason}'
        if response_str == '204 No Content':
            self.logger.info(f'{order_data['OrderNbr']}: Addresses validated!')
            response_str = '204 No Content (SUCCESS)'
        else:
            self.logger.error(f'{order_data['OrderNbr']}: Issue validating addresses!')

        self.helper.format_data_log_entry(entity='SalesOrder', key_value=order_data['OrderNbr'], operation=f'POST - Validate Address', payload=payload, response=response_str, tstamp=datetime.now(ZoneInfo('America/New_York')), options='append')
        bp = 'here'
    #endregion



    #region target_api
    def target_api(self, endpoint: str, payload_data: dict, operation: str = 'put', descr: str = None): #type: ignore
        """:class:`~integration_platform.connectors.acu_api.AcumaticaAPI`.:meth:`~integration_platform.connectors.acu_api.AcumaticaAPI.target_api`
        ---
        
        Allows us to target the acumatica api with multiple endpoints in one method
        
        Parameters
        ---
        :param (*str*) `endpoint`: The endpoint to append to the base URI.
        :param (*dict*) `payload_data`: Dictionary containing **target_api_update_payload**, **log_success**, **log_error**, **acu_api_data_log**    
        :param (*str*) `operation`: API Operation (**PUT**, **POST**, **GET**)
        :param (*str*) `descr`: What the payload will do (**Override & Update**)
        
        Returns
        ---
        :return `return_bool` (bool): If **descr == 'Override & Update'**, return **True** if success, else **False**
        """        
        if operation == 'put':
            response = self.session.put(f'{self.base_uri}{endpoint}', json=payload_data['target_api_update_payload'])
            bp = 'here'
        elif operation == 'post':
            response = self.session.post(f'{self.base_uri}{endpoint}', json=payload_data['target_api_update_payload'])
        response_str = f'{response.status_code}: {response.reason}'
        data_log = payload_data.get('acu_api_data_log') or {}

        if descr in ['Override & Update']:
            try:
                json_response = response.json()
                self.logger.info(payload_data['log_success'])
                return_bool = True
            except Exception as e:
                self.logger.info(payload_data['log_error'])
                return_bool = False
            self.helper.format_data_log_entry(entity=data_log['Entity'], key_value=data_log['Entity'], operation=data_log['Entity'], payload=data_log['Payload'], response=response_str, tstamp=datetime.now(ZoneInfo('America/New_York')), options='append')
        elif descr == 'Reclassify Transaction':
            self.helper.reclassify_transaction_response(payload_data=payload_data, response=response)
            self.helper.format_data_log_entry(entity=data_log['Entity'], key_value=data_log['Entity'], operation=data_log['Entity'], payload=data_log['Payload'], response=response_str, tstamp=datetime.now(ZoneInfo('America/New_York')), options='append')

        elif descr == 'Manage Sales Allocation':
            if response_str == '202: Accepted':
                self.logger.info(payload_data['log_success'])
                return_bool = True
            else:
                self.logger.info(payload_data['log_error'])
                return_bool = False
            self.helper.format_data_log_entry(entity=data_log['Entity'], key_value=data_log['Entity'], operation=data_log['Entity'], payload=data_log['Payload'], response=response_str, tstamp=datetime.now(ZoneInfo('America/New_York')), options='append')
            bp = 'here'

        elif descr in ['Ship Separately', 'Update Warehouse']:
            try:
                json_response = response.json()
                if json_response.get('error') != None:
                    error = json_response['error']
                    self.logger.error(f'Error! {error}')
                    bp = 'here'
                self.logger.info(f'Success!')
                return json_response
            except Exception as e:
                self.logger.error(f'Error! {e}')
                return {}
        elif descr in ['Prepare Shopify', 'Process Shopify']:
            if response_str in ['202: Accepted', '204: No Content']:
                self.logger.info(f'{response_str}, {payload_data['log_success']}')
                return_bool = True
            else:
                self.logger.info(f'{response_str}, {payload_data['log_error']}')
                return_bool = False
            self.helper.format_data_log_entry(entity=data_log['Entity'], key_value=data_log['Entity'], operation=data_log['Entity'], payload=data_log['Payload'], response=response_str, tstamp=datetime.now(ZoneInfo('America/New_York')), options='append')
            bp = 'here'
        return return_bool
    #endregion





    #region get_order_details
    def get_order_details(self, order_data: dict, additional_details: str = '') -> dict:
        ''':class:`~integration_platform.connectors.acu_api.AcumaticaAPI`.:meth:`~integration_platform.connectors.acu_api.AcumaticaAPI.get_order_details`
        ---
        
        Retrieves order details from Acumatica via API
        
        Parameters
        ---
        :param (*dict*) `order_data`:  dictionary containing at least OrderType and OrderNbr
        
                
           ### ***Optional***
        :param (*str*) `additional_details`: Additional data to get from API, for example, pass `?$expand=Shipments` to get Shipment details with response

            - #### To retrieve an attribute, pass it as follows: ?$custom=Document.AttributeAFTSHIPID
        
        Returns
        ---
        :return `order_data` (dict): order_data dict that was parameter, but with BillingValidated and ShippingValidated added
        
        <hr>
        
        ## Upstream Calls (Methods/Functions Called by)
        
         ### :class:`~integration_platform.pipelines.address_validator.AddressValidator`.:class:`~integration_platform.load.address_validator.Load`.:meth:`~integration_platform.load.address_validator.Load.validate_remove_hold_create`
                
         ### :class:`~integration_platform.pipelines.ship_chair_removal_separate.ShipChairRemovalSeparate`.:class:`~integration_platform.load.acu_api_loader.AcuAPILoader`.:meth:`~integration_platform.load.acu_api_loader.AcuAPILoader.__update_ship_sep_or_wh__`
                      
         ### :class:`~integration_platform.pipelines.address_validator.AddressValidator`.:class:`~integration_platform.load.address_validator.Load`.:meth:`~integration_platform.load.address_validator.Load.landing`
        '''
        try:
            response = self.session.get(f'{self.base_uri}/SalesOrder/{order_data['OrderType']}/{order_data['OrderNbr']}{additional_details}')
            order_info = response.json()
            try:
                order_data['ShippingValidated'] =       order_info['ShipToAddressValidated']['value']
                order_data['ShipToAddressOverride'] =   order_info['ShipToAddressOverride']['value']
                order_data['BillingValidated'] =        order_info['BillToAddressValidated']['value']
                order_data['BillToAddressOverride'] =   order_info['BillToAddressOverride']['value']
                
                order_data['ShipToContactOverride'] =   order_info['ShipToContactOverride']['value']
                order_data['BillToContactOverride'] =   order_info['BillToContactOverride']['value']

            except Exception as e:
                bp = 'here'
        except Exception as e:
            order_info = None
            self.logger.error(f'Error getting {order_data['OrderNbr']}')
            return order_data
        bp = 'here'
        order_data = {**order_data, 'acu_response': order_info}
        return order_data
    #endregion

    #region order_remove_hold
    def order_remove_hold(self, order_data: dict):
        ''':class:`~integration_platform.connectors.acu_api.AcumaticaAPI`.:meth:`~integration_platform.connectors.acu_api.AcumaticaAPI.order_remove_hold`
        ---
        
        Given a dictionary containing OrderType and OrderNbr, removes an Order from hold
        
        Parameters
        ---
        :param (*dict*) `order_data`: dictionary containing at least OrderType and OrderNbr
            
        <hr>
        
        ### Upstream Calls 
         #### Address Validator - :class:`~load.address_validator.Load`.:meth:`~load.address_validator.Load.landing`
        '''
        self.logger.info(f'{order_data['OrderNbr']}: Removing Order from hold')
        bp = 'here'   
        payload = self.helper.format_order_remove_hold(order=order_data)

        response = self.session.post(f'{self.base_uri}/SalesOrder/RemoveFromHold', json=payload)
        response_str = f'{response.status_code} {response.reason}'        
        if response_str == '204 No Content':
            self.logger.info(f'{order_data['OrderNbr']} removed from hold successfully!')
            response_str = '204 No Content (SUCCESS)'
        else:
            self.logger.error(f'{order_data['OrderNbr']}: Issue removing from hold')
        
        self.helper.format_data_log_entry(entity='SalesOrder', key_value=order_data['OrderNbr'], operation=f'POST - Remove Hold', payload=payload, response=response_str, tstamp=datetime.now(ZoneInfo('America/New_York')), options='append')
    #endregion



    #region order_do_action
    def order_do_action(self, order_data: dict, payload: dict, action: str):
        ''':class:`~`.:meth:`~order_do_action`
        ---
        
        put_summary_here
        
        Parameters
        ---
        :param (*dict*) `order_data`: _description_
        :param (*dict*) `payload`: _description_
        :param (*str*) `action`: _description_
        
                
           ### ***Optional***
        :param (*str = ''*) `log_prefix`: String to prepend to any logger outputs. Usually used when iterating, like `'keyvalue1, 1/150: '`, `'keyvalue2, 2/150: '` and so on 
        
        <hr>
        
        Returns
        ---
        
        <hr>
        
        ## Upstream Calls (Methods/Functions Called by)
        
         ### _______replace_me_______
        
          - Description
        
         ### _______replace_me_______
           
          - Description
           
         ### _______replace_me_______
        
          - Description
        
        ## Downstream Calls (Methods/Functions called)
        
         ### _______replace_me_______
        
          - Description
        
         ### _______replace_me_______
           
          - Description
           
         ### _______replace_me_______
        
          - Description
        '''        
        try:
            self.logger.info(f'{order_data['OrderNbr']}: Performing {action}')
            url = f'{self.base_uri}/SalesOrder/{action}'
            response = self.session.post(url=url, json=payload)
            response_str = f'{response.status_code} {response.reason}'
            self.logger.info(f'{response_str}. {response.text}')
            bp = 'here'
        except Exception as e:

            bp = 'here'
    #endregion
    #endregion SalesOrder




    #region Shipment

    #MARK: shipment_details
    def shipment_details(self, shipment_data: dict):
        '''shipment_details`(self, shipment_data)`
        ---

        * Gets Shipment details for a given *Shipment*

        * API Method: **GET**

        <hr>

        Parameters
        ---
        :param (*dict*) shipment_data: Dictionary containing details of Shipment

            - Required: **ShipmentNbr**
        
        <hr>

        Returns
        ---

            __response.json()__ (dict): Parsed Dictionary of response from API
        '''
        self.logger.info(f'Retrieving Shipment Details from Acu API for {shipment_data['ShipmentNbr']}')
        try:
            response = self.session.get(f'{self.base_uri}/Shipment/{shipment_data['ShipmentNbr']}?$expand=Details/Allocations,Packages')
            response_details = self.parse_shipment_details(shipment_data, response)
            # if response_details['package_count'] == 0:
            return response_details
        except Exception as e:
            self.logger.error(f'Error getting packages for {shipment_data['ShipmentNbr']}')
            return {}

    #MARK: shipment_details_attr
    def shipment_details_attr(self, shipment_data: dict):
        '''shipment_details`(self, shipment_data)`
        ---
        <hr>

        * Gets Shipment details for a given *Shipment*, along with whether or not it was Sent to WH

        * API Method: **GET**
        
        <hr>

        Parameters
        ---

        :param (*dict*) `shipment_data`: Dictionary containing details of Shipment
        :type shipment_data: dict
        
        - Required
            - **ShipmentNbr**, **OrderNbr**

        <hr>
        
        Returns
        ---

            `response.json()` (dict): Parsed Dictionary of response from API
        '''
        self.logger.info(f'Retrieving Shipment Details from Acu API for {shipment_data['ShipmentNbr']}')
        try:
            response = self.session.get(f'{self.base_uri}/Shipment/{shipment_data['ShipmentNbr']}?$custom=Document.AttributeSHP2WH&$expand=Details/Allocations,Packages')
            response_details = self.parse_shipment_details(shipment_data, response)
            # if response_details['package_count'] == 0:
            return response_details
        except Exception as e:
            self.logger.error(f'Error getting packages for {shipment_data['ShipmentNbr']} ({shipment_data['OrderNbr']})')
            return {}
        
    #MARK: add_package
    def add_package(self, shipment_data: dict):
        '''add_package`(self, shipment_data: *dict*)`
        ---
        <hr>

        Given a Shipment, creates and packs a package

        <hr>

        Parameters
        ---
        :param (*dict*) `shipment_data`: Shipment data. Must include Line details

        Required:
        - **ShipmentNbr**
        - **ExtRefNbr** or **TrackingNbr**
        - **details**
        - **details.InventoryCD**
        - **details.Qty**
        - **details.SplitLineNbr**

        <hr>

        Returns
        -------------

            `shipment_data` (dict): Shipment data with package details

        '''
        self.logger.info(f'Adding package to {shipment_data['ShipmentNbr']}')
        now = datetime.now(ZoneInfo('America/New_York')).strftime('%m/%d/%Y %H:%M:%S')
        descr = f'Package added via API @ {now}'
        tracking_nbr = shipment_data['ExtRefNbr'] if shipment_data.get('ExtRefNbr') else shipment_data['TrackingNbr'] if shipment_data.get('TrackingNbr') else 'No ExtRefNbr for tracking'
        body = {
            "ShipmentNbr": { "value": f"{shipment_data['ShipmentNbr']}" },
            "Packages": [
                {
                "BoxID": { "value": "DEFAULT BOX" },
                "TrackingNbr": { "value": f"{tracking_nbr}" },
                "Description": { "value": f"{descr}" },
                "Weight": { "value": 0 },
                "UOM": { "value": "LBS" },
                
                }
            ]
        }
        body['Packages'][0]['PackageContents'] = [
            {
                "InventoryID": { "value": line['InventoryCD'] },
                "Quantity": { "value": line['Qty'] },
                "UOM": { "value": "EA" },
                "ShipmentSplitLineNbr": { "value": line['SplitLineNbr'] }
            }
            for line in shipment_data['details']
        ]
        shipment_data = self.get_package_details(shipment_data, body)
        return shipment_data


    #MARK: add_package_v2
    def add_package_v2(self, shipment_data: dict):
        '''`add_package_v2`(self, shipment_data: *dict*):
        ---
        <hr>
        
        Revised version of add_package. Used in RedStag.

        Instead of formatting the package within function like `add_package`, format it beforehand and pass the completed payload inside *shipment_data*
        
        <hr>
        
        Parameters
        ----------
        
        :param `shipment_data`: Dictionary of Shipment data
        :type shipment_data: dict

        - Required: **ShipmentNbr**, **PackagePayload**'''
        
        self.logger.info(f'Adding package to {shipment_data['ShipmentNbr']}')
        shipment_data = self.get_package_details(shipment_data, shipment_data['PackagePayload'])
        bp = 'here'
        return shipment_data

    #MARK: get_package_details
    def get_package_details(self, shipment_data, body=None):
        '''`get_package_details`(self, shipment_data)
        ---
        <hr>
    
        Given a Shipment, returns Package details


        Parameters
        -------------
        <hr>

            `shipment_data` (dict): Dictionary of Shipment data
            `body` (dict): JSON payload sent to API


        Returns
        -------------
        <hr>

        `shipment_data` (dict): shipment_data with Package data
            - Required: **ShipmentNbr**
            '''
        verb = 'added to'
        now = ' now '
        if body == None:
            verb = 'retrieved from'
            now = ' '
            body = {
                "ShipmentNbr": { "value": f"{shipment_data['ShipmentNbr']}" },
            }
        response = self.session.put(url=f'{self.base_uri}/Shipment?$expand=Packages/PackageContents', json=body)
        json_response = response.json()
        if response.ok:            
            self.logger.info(f'Package data {verb} {shipment_data['ShipmentNbr']}!')
            shipment_data = {**shipment_data, 'Packages': json_response['Packages'], 'package_count': json_response['PackageCount']['value']}
            response_str = f'{response.status_code} {response.reason}. {shipment_data['ShipmentNbr']}{now}has {json_response['PackageCount']['value']} packages.'
            self.logger.info(response_str)
        if not response.ok:
            self.logger.error(f'get_package_details failed ({response.status_code}): {json_response.get('error')}')
            response_str = f'{response.status_code} {json_response.get('error')}'
            self.logger.warning(response_str)
        self.helper.format_data_log_entry(entity='Shipment', key_value=shipment_data['ShipmentNbr'], operation=f'PUT: Package {verb} {shipment_data['ShipmentNbr']}!', payload=body, response=response_str, tstamp=datetime.now(ZoneInfo('America/New_York')), options='append')
        return shipment_data

    #MARK: confirm_shipment
    def confirm_shipment(self, shipment_data: dict):
        ''':class:`~integration_platform.connectors.acu_api.AcumaticaAPI`.:meth:`~integration_platform.connectors.acu_api.AcumaticaAPI.confirm_shipment`
        ---
        
        Given a dict of shipment data, ***`ShipmentNbr` required***, confirm the shipment in acumatica
        
        Parameters
        ---
        :param (*dict*) `shipment_data`: dict containing `ShipmentNbr`

        <hr>
        
        ## Downstream Calls (Methods/Functions called)
        
         ### :class:`~integration_platform.helpers.acu_api_helper.AcumaticaAPIHelper`.:meth:`~integration_platform.helpers.acu_api_helper.AcumaticaAPIHelper.format_data_log_entry`
        '''
        self.logger.info(f'Confirming Shipment {shipment_data['ShipmentNbr']}')
        body = {
            "entity": {
                "Type": {
                    "value": "Shipment"
                },
                "ShipmentNbr": {
                    "value": f"{shipment_data['ShipmentNbr']}"
                }
            }
        }
        response = self.session.post(url=f'{self.base_uri}/Shipment/ConfirmShipment', json=body)
        response_str = f'{response.status_code} {response.reason}'
        self.logger.info(f'{response.status_code} {response.reason}')
        self.helper.format_data_log_entry(entity='Shipment', key_value=shipment_data['ShipmentNbr'], operation='POST - Confirm Shipment', payload=body, response=response_str, tstamp=datetime.now(ZoneInfo('America/New_York')), options='append')



    #MARK: update_reason_code
    def update_reason_code(self, shipment_data: dict, line_data: dict):
        ''':class:`~integration_platform.connectors.acu_api.AcumaticaAPI`.:meth:`~integration_platform.connectors.acu_api.AcumaticaAPI.update_reason_code`
        ---
        
        Updates Reason Code on the line of a Shipment to *RETURN*
        
        Parameters
        ---
        :param (*dict*) `shipment_data`: Shipment data
        :param (*dict*) `line_data`: For each line on Shipment, line_data is that line's data dict
        
        Returns
        ---
        :return `line_data` (*dict*): Line data with updated Reason Code
        
        <hr>
        
        ## Upstream Calls (Methods/Functions Called by)
        
         ### :class:`~integration_platform.load.shipment_api.Load`.:meth:`~integration_platform.load.shipment_api.Load.check_reason_code`
        
        ## Downstream Calls (Methods/Functions called)
        
         ### :class:`~integration_platform.helpers.acu_api_helper.AcumaticaAPIHelper`.:meth:`~integration_platform.helpers.acu_api_helper.AcumaticaAPIHelper.format_data_log_entry`
        '''
        self.logger.info(f'Updating ReasonCode on line {line_data['LineNbr']} of {shipment_data['ShipmentNbr']} from {line_data['ReasonCode']} to RETURN')
        body = {
            "ShipmentNbr": { "value": f"{shipment_data['ShipmentNbr']}" },
            "Details": [
                {
                "LineNbr":    { "value": line_data['LineNbr'] },
                "ReasonCode": { "value": "RETURN" }
                }
            ]
        }
        response = self.session.put(url=f'{self.base_uri}/Shipment', json=body)
        if response.ok:
            line_data['ReasonCode'] = 'RETURN'
        response_str = f'{response.status_code} {response.reason}'
        self.helper.format_data_log_entry(entity='Shipment', key_value=shipment_data['ShipmentNbr'], operation='PUT - Update ReasonCode on Shipment Line', payload=body, response=response_str, tstamp=datetime.now(ZoneInfo('America/New_York')), options='append')
        return line_data

    #MARK: send_to_wh
    def send_to_wh(self, ShipmentNbr, CustomerID):
        ''':class:`~integration_platform.connectors.acu_api.AcumaticaAPI`.:meth:`~integration_platform.connectors.acu_api.AcumaticaAPI.send_to_wh`
        ---
        
        Mark a shipment as sent to warehouse in Acumatica
        
        Parameters
        ---
        :param (*str*) `ShipmentNbr`: ShipmentNbr of shipment to mark as sent
        :param (*str*) `CustomerID`: CustomerID of customer on Shipment
        
        Returns
        ---
        :return `self.status_description` (*str*): Details of interaction with Acumatica API

        :return `body` (*dict*): Dictionary of what was sent to Acumatica API
        
        <hr>
        
        ## Downstream Calls (Methods/Functions called)
        
         ### :class:`~integration_platform.connectors.acu_api.AcumaticaAPI`.:meth:`~integration_platform.connectors.acu_api.AcumaticaAPI.parse_response`
        
         ### :class:`~integration_platform.connectors.acu_api.AcumaticaAPI`.:meth:`~integration_platform.connectors.acu_api.AcumaticaAPI.send_to_wh`
        '''        

        body = {
            "CustomerID": { "value": f"{CustomerID}" },
            "ShipmentNbr": { "value": f"{ShipmentNbr}" },
            "custom": {
                "Document": {
                    "AttributeSHP2WH": {
                        "value": True
                    }
                }
            } 
        }
        try:
            response = self.session.put(f'{self.base_uri}/Shipment', json=body)
            self.parse_response(response, {'type': 'Shipment', 'attribute': 'AttributeSHP2WH'})
        except Exception as e:
            try:                    
                self._logout_()
                self._auth_()
                response = self.session.put(f'{self.base_uri}/Shipment', json=body)
                self.parse_response(response, {'type': 'Shipment', 'attribute': 'AttributeSHP2WH'})
            except Exception as e:
                self.status_description = 'FAILURE'
                bp = 'here'
        self.helper.format_data_log_entry(entity='Shipment', key_value=ShipmentNbr, operation='PUT - Mark Shipment as Sent to WH', payload=body, response=self.status_description, tstamp=datetime.now(ZoneInfo('America/New_York')), options='append')
        return self.status_description, body

    #MARK: rc_send_to_wh_v2
    def rc_send_to_wh_v2(self, OrderNbr: str, OrderType: str, CustomerID: str, attribute_payload: dict = {}, log_prefix: str = ''):
        ''':class:`~integration_platform.connectors.acu_api.AcumaticaAPI`.:meth:`~integration_platform.connectors.acu_api.AcumaticaAPI.rc_send_to_wh_v2`
        ---
        
        Marks an *Order*'s **RC Ship to Warehouse** attribute to true. (**AttributeRCSHP2WH**)

        Additionally, sends the payload included in **attribute_payload**, If none, only **AttributeRCSHP2H** is updated
        
        Parameters
        ---
        :param (*str*) `OrderNbr`: OrderNbr of order to mark as sent
        :param (*str*) `OrderType`: OrderType of order to mark as sent
        :param (*str*) `CustomerID`: CustomerID on order
        
                
           ### ***Optional***
        :param (*dict = {}*) `attribute_payload`: Other attributes and values to send along with marking order as sent
        :param (*str = ''*) `log_prefix`: String to prepend to any logger outputs. Usually used when iterating, like `'keyvalue1, 1/150: '`, `'keyvalue2, 2/150: '` and so on 
        
        Returns
        ---
        :return `status_description` (str): description of api operation result
        :return `body` (dict): what was sent to acu api
        '''  
        body = {
            "CustomerID": { "value": f"{CustomerID}" },
            "OrderType": {"value": f"{OrderType}"},
            "OrderNbr": { "value": f"{OrderNbr}"},
            "custom": {
                "Document": {
                    "AttributeRCSHP2WH": {
                        "value": True
                    },
                    **attribute_payload
                }
            } 
        }
        
        self.logger.info(f'{log_prefix}Sending attribute_payload to Acumatica for Order {OrderNbr}')
        try:
            response = self.session.put(f'{self.base_uri}/SalesOrder', json=body)
            self.parse_response(response=response, entity_type={'type': 'Order', 'attribute': 'AttributeRCSHP2WH'}, log_prefix=log_prefix)
        except Exception as e:
            try:                    
                self._logout_()
                time.sleep(1)
                self._auth_()
                response = self.session.put(f'{self.base_uri}/SalesOrder', json=body)
                self.parse_response(response=response, entity_type={'type': 'Order', 'attribute': 'AttributeRCSHP2WH'}, log_prefix=log_prefix)
            except Exception as e:
                self.status_description = 'FAILURE'
        self.helper.format_data_log_entry(entity='SalesOrder', key_value=OrderNbr, operation='PUT - Mark RC Order as Sent To WH', payload=body, response=self.status_description, tstamp=datetime.now(ZoneInfo('America/New_York')), options='append')
        return self.status_description, body
    

    #MARK: send_to_wh_v2
    def send_to_wh_v2(self, ShipmentNbr: str, CustomerID: str, attribute_payload: dict = {}, log_prefix: str = ''):
        '''`sent_to_wh_v2`(self, ShipmentNbr: *str*, CustomerID: *str*, attribute_payload: *dict*)
        ===
        * Marks a *Shipment*'s **Ship to Warehouse** attribute to true. (AttributeSHP2WH)

        * Receives a dynamic payload for additional attribute values to populate

        * API Method: **PUT**
        
        <hr>

        Parameters
        ---
        :param `ShipmentNbr`: ShipmentNbr of Shipment to update
        :type ShipmentNbr: str
        :param `CustomerID`: CustomerID or AcctCD of Customer on Shipment (C0090306, C0067451)
        :type CustomerID: str
        :param `attribute_payload`: Additional Attribute values to populate on Shipment
        :type attribute_payload: dict
            
        <hr>

        Returns
        ---
        :return `self.status_description` (*str*): Details of interaction with Acumatica API

        :return `body` (*dict*): Dictionary of what was sent to Acumatica API'''
        body = {
            "CustomerID": { "value": f"{CustomerID}" },
            "ShipmentNbr": { "value": f"{ShipmentNbr}" },
            "custom": {
                "Document": {
                    "AttributeSHP2WH": {
                        "value": True
                    },
                    **attribute_payload
                }
            } 
        }
        try:
            self.logger.info(f'{log_prefix}Sending attribute_payload to Acumatica for Shipment {ShipmentNbr}')
            response = self.session.put(f'{self.base_uri}/Shipment', json=body)
            self.parse_response(response=response, entity_type={'type': 'Shipment', 'attribute': 'AttributeSHP2WH'}, log_prefix=log_prefix)
        except Exception as e:
            try:                    
                self._logout_()
                self._auth_()
                response = self.session.put(f'{self.base_uri}/Shipment', json=body)
                self.parse_response(response=response, entity_type={'type': 'Shipment', 'attribute': 'AttributeSHP2WH'}, log_prefix=log_prefix)
            except Exception as e:
                self.status_description = 'FAILURE'
        self.helper.format_data_log_entry(entity='Shipment', key_value=ShipmentNbr, operation='PUT - Mark Shipment as Sent to WH', payload=body, response=self.status_description, tstamp=datetime.now(ZoneInfo('America/New_York')), options='append')
        return self.status_description, body
    
#endregion Shipment



#region Utility
    #MARK: parse_shipment_details
    def parse_shipment_details(self, shipment_data: dict, response: requests.Response):
        '''`parse_shipment_details`(self, shipment_data, response)
        ===
        Given the Acumatica API's *response*, convert to JSON and combine with shipment_data.

        API response contains the detailed information regarding the shipment, including line details

        <hr>

        Parameters
        ---
        :param `shipment_data`: Dictionary containing details of Shipment
        :type shipment_data: dict
        :param `response`: Response from Acumatica API (Shipment endpoint)
        :type response: requests.Response

         
        <hr>

        Returns
        ---

         `shipment_details` (*dict*): **shipment_data**, but with added *Status*, *package_count*, *line_count* and *details* values
        
         - **shipment_details['*Status*']**

            - Status of Shipment in Acumatica   
            
         - **shipment_details['*package_count*']**

            - How many packages are currently on the Shipment
            
         - **shipment_details['*line_count*']**

            - How many lines are currently on the shipment
            
         - **shipment_details['*details*']**
        
            - LineNbr, InventoryCD, Qty, SplitLineNbr, ReasonCode and id *for each line* on Shipment
        '''
        try:
            json_response = response.json()
        except Exception as e:
            self.logger.error(f'Could not parse response!')
            return {
                'data': response,
                'status': 'Error'
            }
        package_count = json_response['PackageCount']['value']
        line_count = len(json_response['Details'])
        details = [{
            'LineNbr': line['LineNbr']['value'],
            'InventoryCD': line['InventoryID']['value'],
            'Qty': line['ShippedQty']['value'],
            'SplitLineNbr': line['Allocations'][0]['SplitLineNbr']['value'],
            'ReasonCode': line['ReasonCode']['value'],
            'id': line['id']
        } for line in json_response['Details']]

        shipment_details = {
            **shipment_data,
            'Status': json_response['Status']['value'],
            'package_count': package_count,
            'line_count': line_count,
            'details': details
        }
        self.logger.info(f'{json_response['ShipmentNbr']['value']} - Packages: {package_count}. Lines: {line_count}')
        return shipment_details
    #endregion

    #region parse_response
    def parse_response(self, response: requests.Response, entity_type: dict, log_prefix: str = ''):
        status_code = response.status_code
        if status_code == 200:
            self.acu_response = json.loads(response.text)
            for key, value in self.acu_response.items():
                if "{'value'" in str(value):
                    self.acu_response[key] = value['value']
                    bp = 'here'
                else:
                    self.acu_response[key] = value

            is_sent = self.acu_response['custom']['Document'][entity_type['attribute']]['value']
            if self.acu_response['Status'] != 'Open':
                self.status_description = f'{self.acu_response[f'{entity_type['type']}Nbr']} is {self.acu_response['Status']}! SentToWH = {is_sent}'
                self.logger.error(self.status_description)
            elif is_sent:
                self.status_description = f'{self.acu_response[f'{entity_type['type']}Nbr']} has been marked as sent in Acumatica!' 
                self.logger.info(self.status_description)
            else:
                self.status_description = f'{self.acu_response[f'{entity_type['type']}Nbr']} was not marked as sent and is in Open status!'
                self.logger.error(self.status_description)
        else:
            self.status_description = 'FAILURE'
            bp = 'here'
    #endregion
#endregion Utility


#region Customer/Contact
    #region customers
    def customers(self, query=None, limit=100):
        '''customers`(self, query=None, limit=100)`
        ===
        * Gets Customer details

        * API Method: **GET**

        Parameters
        ---
        <hr>

            __query__ (str | None): Query to filter response (default = None)
            __limit__ (int): Number of results to limit to (default = 100)
        
        Returns
        ---
        <hr>

            __response.json()__ (dict): Parsed Dictionary of response from API
        '''
        params = {
            "$expand": "MainContact,MainContact/Address",
            "$select": "CustomerID,CustomerName,CustomerClass,MainContact/Email,"
                       "MainContact/Phone1,MainContact/Address/AddressLine1,"
                       "MainContact/Address/AddressLine2,MainContact/Address/City,"
                       "MainContact/Address/State,MainContact/Address/PostalCode,"
                       "CreatedDateTime,LastModifiedDateTime",
            "$top": str(limit),
        }
        if query:
            params["$filter"] = query
        response = self.session.get(f'{self.base_uri}/Customer', params=params)
        response.raise_for_status()
        return response.json()
    #endregion

    #region contact
    def contact(self, query=None, limit=100):
        '''contact`(self, query=None, limit=100)`
        ===
        * Gets Customer Contact details

        * API Method: **GET**

        Parameters
        ---
        <hr>

            __query__ (str | None): Query to filter response (default = None)
            __limit__ (int): Number of results to limit to (default = 100)
        
        Returns
        ---
        <hr>

            __response.json()__ (dict): Parsed Dictionary of response from API
        '''
        params = {
            "$expand": "Address",
            "$select": "ContactID,FirstName,LastName,Email,Phone1,Phone2,"
                    "JobTitle,Status,BusinessAccount,"
                    "Address/AddressLine1,Address/AddressLine2,"
                    "Address/City,Address/State,Address/PostalCode",
            "$filter": query,
            "$top": str(limit),
        }
        if query:
            params["$filter"] = query
        response = self.session.get(f'{self.base_uri}/Contact', params=params)
        response.raise_for_status()
        return response.json()
    #endregion
    #endregion Customer/Contact





    #region Authentication/Logout
    def _auth_(self):
        self.session = requests.Session()
        if self.env == 'dev':
            self.session.headers.update({
                'CF-Access-Client-Id': ACUMATICA_API['cf_client_id'] or '',
                'CF-Access-Client-Secret': ACUMATICA_API['cf_client_secret'] or '',
            })
        body = {
            "name": self.username,
            "password": self.password,
            "company": self.company
        }
        try:
            response = self.session.post(url=f'{self.auth_url}/login', json=body)
            response.raise_for_status()
            self.logger.info('Acumatica API is online. Logged into Acumatica and authenticated successfully')
        except Exception as e:
            self.login_attempts += 1
            sleep = 15
            self._logout_()
            if self.login_attempts == 1:
                self.username = self.username2
                self.password = self.password2
                self.logger.warning(f'Failed to login on first attempt with default credentials, retrying with backup creds...')
            elif self.login_attempts <= 5:
                self.logger.warning(f'Failed to login with backup credentials...Waiting {sleep} seconds and trying again...Attempt {self.login_attempts - 1}/4' )
                time.sleep(sleep)
            elif self.login_attempts == 6:
                self.logger.error(f"Couldn't login to Acumatica after one attempt with default creds and four attempts with backup creds... Now trying alternate backup credentials.")
                self.username = self.username3
                self.password = self.password3
            elif self.login_attempts < 10:
                self.logger.warning(f'Failed to login with alt backup credentials...Waiting {sleep} seconds and trying again...Attempt {self.login_attempts - 1}/4' )
                self.logger.info(f'Sleeping {sleep}')
                time.sleep(sleep)
            else:
                raise e
            self._auth_()
        pass

    #MARK: _logout_
    def _logout_(self):
        self.session.post(f'{self.auth_url}/logout')
        self.logger.info('Logged out of Acumatica API session')
        pass
#endregion Authentication/Logout







    #MARK: reclassify_transaction
    def reclassify_transaction(self, cogs_entry: dict):
        bp = 'here'
        full_payload = self.helper.format_reclassify_transaction(cogs_entry=cogs_entry)
        self.target_api(endpoint='/JournalTransaction/ReclassifyCorrections', payload_data=full_payload, operation='post', descr='Reclassify Transaction')



    #MARK: manage_sales_allocations
    def manage_sales_allocations(self, order_data: dict):
        full_payload = self.helper.format_manage_sales_allocations(order_data=order_data)
        self.target_api(endpoint='/ManageSalesAllocations/ProcessAllAllocations', payload_data=full_payload, operation='post', descr='Manage Sales Allocation')
        bp = 'here'






    #MARK: prepare_shopify
    def prepare_shopify(self, entity: str = 'Product Availability'):
        full_payload = self.helper.format_prepare_shopify(entity=entity)
        self.target_api(endpoint='/PrepareShopify/PrepareEntity', payload_data=full_payload, operation='post', descr=f'Prepare Shopify')
        bp = 'here'
    

    #MARK: process_shopify
    def process_shopify(self, entity_data: dict, entity: str = 'Product Availability'):
        full_payload = self.helper.format_process_shopify(entity_data=entity_data, entity=entity)
        self.target_api(endpoint='/ProcessShopify/ProcessEntity', payload_data=full_payload, operation='post', descr=f'Process Shopify')
        bp = 'here'
    
    #MARK: get_process_shopify_records
    def get_process_shopify_records(self, entity: str = 'Product Availability', store: str = 'ShopJourneyProductio'):
        params = {
            "$filter": f"Store eq '{store}' and EntityName eq '{entity}'"
        }
        response = self.session.get(f'{self.base_uri}/ProcessShopify', params=params)
        jresponse = response.json()
        return response.json()

